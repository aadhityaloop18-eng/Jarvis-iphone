JARVIS iPhone Starter — Version 1

WHAT THIS IS
A lightweight installable web-app prototype. It includes a futuristic interface,
basic command routing, web search, opening YouTube, and spoken responses using
voices provided by iOS/browser. It is NOT yet a general-purpose AI agent.

IMPORTANT LIMITATIONS
- This prototype does not contain an AI model connection.
- OpenAI API usage is separate from a ChatGPT subscription and may cost money.
- Never put an API key in app.js, HTML, or any public file.
- iOS browser speech recognition support varies. If the microphone button says
  recognition is unavailable, use the microphone on the iPhone keyboard.
- A website cannot freely control other iPhone apps or reliably run in the
  background. Use Apple Shortcuts for supported actions.
- Messages and purchases must be reviewed and confirmed by the user/account holder.

DEPLOYMENT FROM IPHONE (GitHub Pages)
1. In Safari, sign in to GitHub or create an account with the account holder's help.
2. Create a new repository named jarvis-iphone. Choose Public for free GitHub Pages.
3. Upload the contents of this folder (index.html, style.css, app.js,
   manifest.webmanifest, sw.js, README.txt) to the repository root.
4. In the repository, open Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select branch main and folder /(root), then Save.
7. Wait for GitHub Pages to publish. Open the Pages URL shown in Settings.
8. In Safari, tap Share > Add to Home Screen > Add.

VOICE
Open Settings (gear) inside Jarvis. Choose an installed voice if available.
The deep cinematic effect is approximated with slower speed and lower pitch;
iOS controls which voices are available.

SHORTCUTS
The prototype can launch a named shortcut with a command like:
  run shortcut Jarvis Reminder
Create the shortcut yourself in Apple's Shortcuts app and test it before use.
The browser will ask for confirmation before opening it.

NEXT DEVELOPMENT PHASE
Add a secure backend for AI requests. Keep API credentials on the server,
not in this static website. Then add narrowly scoped tools for reminders,
message drafts, app launching, search and shopping research. Require approval
before sending messages, making purchases, or changing important data.
