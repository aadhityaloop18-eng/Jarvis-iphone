const $ = (id) => document.getElementById(id);
const chat = $("chat"), command = $("command"), statusEl = $("status"), voiceBtn = $("voiceBtn");
let selectedVoice = null;

function addMessage(who, text) {
  const item = document.createElement("article");
  item.className = "msg " + who;
  const label = document.createElement("b");
  label.textContent = who === "user" ? "YOU" : "JARVIS";
  const p = document.createElement("p");
  p.textContent = text;
  item.append(label, p); chat.append(item); chat.scrollTop = chat.scrollHeight;
}
function speak(text) {
  if (!("speechSynthesis" in window)) return;
  speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text);
  const voices = speechSynthesis.getVoices();
  const chosen = voices.find(v => v.name === $("voiceSelect").value);
  if (chosen) u.voice = chosen;
  u.rate = Number($("rate").value); u.pitch = Number($("pitch").value);
  u.onstart = () => statusEl.textContent = "JARVIS SPEAKING";
  u.onend = () => statusEl.textContent = "SYSTEM STANDBY";
  speechSynthesis.speak(u);
}
function openShortcut(name) {
  const url = "shortcuts://run-shortcut?name=" + encodeURIComponent(name);
  window.location.href = url;
}
function respond(text) { addMessage("jarvis", text); speak(text); }

function handle(text) {
  const q = text.trim(); if (!q) return;
  addMessage("user", q); command.value = "";
  const lower = q.toLowerCase();

  if (lower.includes("what can you do") || lower.includes("help")) {
    respond("I can open supported websites, search the web, speak responses, and guide you through reminders and Shortcuts. More AI features will be added when you connect a secure AI backend.");
  } else if (lower.includes("open youtube")) {
    respond("Opening YouTube. One moment.");
    window.location.href = "https://www.youtube.com";
  } else if (lower.startsWith("search for ") || lower.startsWith("search ")) {
    const term = q.replace(/^search for |^search /i, "");
    respond("Searching the web for " + term + ".");
    window.location.href = "https://www.google.com/search?q=" + encodeURIComponent(term);
  } else if (lower.includes("reminder")) {
    respond("I can't create a reliable iPhone reminder directly from this web prototype yet. Create an Apple Shortcut named Jarvis Reminder, then connect it here. For now, open the Reminders app and add your reminder there.");
    setTimeout(() => { if (confirm("Open the Reminders app?")) window.location.href = "x-apple-reminderkit://"; }, 500);
  } else if (lower.startsWith("run shortcut ")) {
    const name = q.slice("run shortcut ".length).trim();
    if (name && confirm("Run the iPhone Shortcut named “" + name + "”?")) openShortcut(name);
  } else if (lower.includes("message") || lower.includes("send")) {
    respond("I can help draft a message, but I won't send it automatically. Tell me the message text and recipient, then review it in your messaging app before sending.");
  } else if (lower.includes("order") || lower.includes("buy")) {
    respond("I can help research products and compare options. Before any purchase, review the seller, total price, delivery details and get the account holder's approval. I cannot submit payment from this prototype.");
  } else {
    respond("I heard you say: " + q + ". This starter version has basic commands. For general reasoning and custom actions, we'll connect a secure AI service in the next phase.");
  }
}
$("commandForm").addEventListener("submit", e => { e.preventDefault(); handle(command.value); });
document.querySelectorAll("[data-command]").forEach(b => b.addEventListener("click", () => handle(b.dataset.command)));
voiceBtn.addEventListener("click", () => {
  // iOS Safari support for browser speech recognition varies. Use keyboard dictation if unavailable.
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    respond("Voice recognition is not available in this browser. Tap the command box and use the iPhone keyboard microphone for dictation. My spoken responses are available where iOS speech synthesis is supported.");
    command.focus(); return;
  }
  const recognition = new SpeechRecognition();
  recognition.lang = "en-IN"; recognition.interimResults = false; recognition.maxAlternatives = 1;
  recognition.onstart = () => { statusEl.textContent = "LISTENING"; voiceBtn.classList.add("listening"); };
  recognition.onend = () => { statusEl.textContent = "SYSTEM STANDBY"; voiceBtn.classList.remove("listening"); };
  recognition.onerror = () => respond("I couldn't hear that. Please try again or use keyboard dictation.");
  recognition.onresult = e => handle(e.results[0][0].transcript);
  try { recognition.start(); } catch { respond("Please try the microphone again."); }
});
function loadVoices() {
  const select = $("voiceSelect"), current = select.value;
  select.innerHTML = '<option value="">System default</option>';
  (speechSynthesis.getVoices() || []).forEach(v => {
    const opt = document.createElement("option"); opt.value = v.name; opt.textContent = v.name + " (" + v.lang + ")";
    select.append(opt);
  });
  select.value = current;
}
if ("speechSynthesis" in window) { loadVoices(); speechSynthesis.onvoiceschanged = loadVoices; }
$("settingsBtn").addEventListener("click", () => $("settings").showModal());
$("rate").addEventListener("input", e => $("rateValue").value = e.target.value);
$("pitch").addEventListener("input", e => $("pitchValue").value = e.target.value);
if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
  window.addEventListener("load", () => navigator.serviceWorker.register("./sw.js").catch(()=>{}));
}
